package com.base2.selenium.driverutil;

public enum DriverType {
    CHROME
}
